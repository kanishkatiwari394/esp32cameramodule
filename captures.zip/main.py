from fastapi import FastAPI, UploadFile, File, Form
from pathlib import Path
from datetime import datetime
import uvicorn

app = FastAPI()

CAPTURE_DIR = Path("captures")
CAPTURE_DIR.mkdir(exist_ok=True)


@app.get("/")
def root():
    return {
        "status": "Raksha Rail capture server running"
    }


@app.post("/api/device/detection")
async def receive_detection(
    image: UploadFile = File(...),
    rfidUid: str = Form(""),
    readerId: str = Form(""),
):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")

    uid = rfidUid.replace(":", "")
    reader = readerId.replace(" ", "_")

    filename = f"{timestamp}_{reader}_{uid}.jpg"
    filepath = CAPTURE_DIR / filename

    image_data = await image.read()

    with open(filepath, "wb") as f:
        f.write(image_data)

    return {
        "success": True,
        "filename": filename,
        "message": "Image saved successfully"
    }


if __name__ == "__main__":
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000
    )